import React from "react";

class GameCell extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            disable: false,
            content: '?'
        }
    }

    componentDidUpdate(prevProps) {
        // Typical usage (don't forget to compare props):
        if (prevProps.status !== 'not_started' && this.props.status === "not_started") {
            this.setState({
                disable: false,
                content: '?'
            });
        }
    }

    handleClick = () => {
        if (!this.state.disable && this.props.status !== 'end') {
            let player = this.props.currentPlayer;
            this.setState({
                disable: true,
                content: player
            });
            this.props.handleSelect(this.props.coords, player);
        }
    }

    render() {
        return(
            <div className="game-cell"
                 onClick={this.handleClick}>
                {this.state.content}
            </div>
        );
    }
}

export default GameCell;