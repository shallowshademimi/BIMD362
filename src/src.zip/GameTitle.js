import React from 'react';

export default function GameTitle(){
    return(
        <header id="game-title" >
            <h1>Tic Tac Toe</h1>
        </header>
    );
}



